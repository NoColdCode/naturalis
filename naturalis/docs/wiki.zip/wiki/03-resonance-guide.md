# Resonance Guide

Resonance is the advanced identity system in Naturalis.

It is designed so you feel like the bonded morph is your true body, not just a costume.

## Prerequisite

You need one fully mastered morph (max knowledge level) before bonding it.

## Core concepts

- `Bonded Morph`: your chosen primary morph identity
- `Resonance Active`: bonded mode enabled
- `Burst`: short power window with cooldown
- `Strain`: identity stress meter from `0` to `100`
- `Archetype`: bonded morph style (`predator`, `survivor`, `aquatic`, or `other`)

## How it works

1. Bond a mastered morph.
2. Activate Resonance.
3. Stay in bonded form to keep identity aligned.
4. Fight and survive as that form to gain mastery XP.

## Alignment and Strain

While Resonance is active:

- If you stay in your bonded morph, strain goes down over time.
- If you are not in your bonded morph, strain goes up.
- At high strain, you get penalties.
- At maximum strain, Resonance collapses and deactivates.

This is the main mechanic that enforces embodiment gameplay.

## Burst

Burst is a short high-impact state.

- Duration: `12` seconds
- Cooldown: `60` seconds
- Requires: bonded morph set, Resonance active, and you currently in bonded form

## Damage profile

Damage is no longer one flat value for all morphs.

It now depends on:

- Bonded archetype
- Whether Burst is active
- Current strain level

This creates different combat identities for different morph families.

## Mastery progression in Resonance

- Kills in aligned bonded form grant mastery XP
- Burst windows and stable low-strain play improve progression
- Milestones unlock advancement progression

## Practical playstyle

- Pick one morph you truly want to main
- Build your routes and fights around that body
- Use Burst intentionally, not on cooldown spam
- Avoid prolonged off-bond play while Resonance is active
