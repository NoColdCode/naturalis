# Natural Dimension Overview

The Natural Dimension is a hostile mirror-ecosystem where identity pressure is constant.

## Entry and portal basics

- Portal requires a valid Natural Portal Frame and a Coven Sigil Key.
- Activating the frame consumes 1 key (unless creative mode).

Portal cooldown values:
- Portal travel cooldown: `80 ticks` (`4 s`)

## Passive dimension pressure

While in Natural Dimension and Resonance is active:
- `-1 humanity` every `60 s`

## Weather identity

Natural Dimension weather behavior:
- Normal rain is suppressed
- Thunderstorms are frequent

During thunderstorms, players can receive:
- Storm Attunement
- Morph Binding

## Rare and important drops inside the dimension

- Warden in Natural Dimension has `2.5%` chance to drop Natural Star.
- Echo Sovereign systems run in this dimension and anchor high-end progression.

## Spawn-hut ring concept

Players are linked to one of multiple fixed hut centers in the dimension.
This creates a ritualized arrival pattern instead of random spawn chaos.
