# Inertia

Inertia is the body-weight movement model.

Your morph mass changes speed feel, jump feel, gravity feel, fall punishment, and knockback resistance.

## Core formulas

### Knockback resistance

- Formula: `mass / (mass + 4)`
- Clamped to `0.00` to `0.85`

### Movement speed multiplier

For mass `<= 3.0`:
- Formula: `1.04 - (mass / 3) x 0.04`

For mass `> 3.0`:
- Formula: `1.0 - ((mass - 3.0) / (mass + 30.0))`

Final clamp:
- `0.75` to `1.08`

### Step height multiplier

- Mass `< 1.0`: `1.10`
- Mass `1.0` to `6.0`: `1.00`
- Mass `> 6.0`: `0.85`

### Fall damage multiplier

- Formula: `1.0 + (mass x 0.15)`
- Clamped to `1.0` to `3.5`

### Gravity multiplier

- Based around neutral mass `2.5`
- Final clamp: `0.90` to `1.12`

### Jump strength multiplier

- Based around neutral mass `2.5`
- Extra light bonus at mass `<=0.8`
- Extra heavy penalty at mass `>=8.0`
- Final clamp: `0.93` to `1.12`

## Practical examples

- Very light morphs feel springy and are harder to pin with knockback.
- Heavy morphs feel grounded, resist knockback more, and take heavier fall punishment.
- Inertia is always active while morphed; it is not an optional perk.
