# Morph Knowledge

Each morph has its own XP and progression. Playing as that morph improves your mastery.

## XP and levels

- Max level: `5`
- Level XP thresholds:
  - Level 0: `0`
  - Level 1: `180`
  - Level 2: `360`
  - Level 3: `720`
  - Level 4: `1280`
  - Level 5: `2000`

## What levels improve

Knowledge branches control different features. Main practical effects:

Vitality rank (health bonus):
- Rank 0: `+0%`
- Rank 1: `+10%`
- Rank 2: `+25%`
- Rank 3: `+45%`
- Rank 4: `+70%`
- Rank 5: `+100%`

Handling rank (hotbar and inventory):
- Rank 0: `3 hotbar slots`
- Rank 1: `4 slots`
- Rank 2: `6 slots`
- Rank 3: `8 slots`
- Rank 4-5: `9 slots`
- Inventory opens only at max handling rank (`5`)

Instinct rank (instinct pressure frequency):
- Rank 0: every `1 tick`
- Rank 1: every `2 ticks`
- Rank 2: every `4 ticks`
- Rank 3: every `8 ticks`
- Rank 4: every `14 ticks`
- Rank 5: disabled

Wander rank (AFK delay before wander behavior):
- Rank 0: `300 ticks` (`15 s`)
- Rank 1: `450 ticks` (`22.5 s`)
- Rank 2: `700 ticks` (`35 s`)
- Rank 3: `1000 ticks` (`50 s`)
- Rank 4: `1400 ticks` (`70 s`)
- Rank 5: disabled

## XP gain rhythm (player-facing)

- Passive gain: `+1 XP` every `600 ticks` (`30 s`) while morphed.
- You also gain XP from movement and behavior in that body style.

## Temporary full unlock item behavior

Knowledge Elixir can temporarily push a specific morph to full branch ranks for a timed window, then normal ranks return after expiry.
